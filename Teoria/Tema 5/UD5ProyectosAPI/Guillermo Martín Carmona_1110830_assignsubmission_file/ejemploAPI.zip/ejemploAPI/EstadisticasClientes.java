package ejemploAPI;

import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public class EstadisticasClientes {

	private TreeMap<Integer, Cliente> lista;

    public EstadisticasClientes(TreeMap<Integer, Cliente> lista) {
        this.lista = lista;
    }
    
    // 1. firstKey
    public String obtenerClienteMasViejo() {
        return "Cliente más antiguo: " + lista.firstKey();
    }
        
    // 2. tailMap
    public String filtrarCliente(Integer id) {
        SortedMap<Integer, Cliente> filtrado = lista.tailMap(id);
        String resultado = ""; // 1. Creamos variable vacía
        for (Integer clave : filtrado.keySet()) {
            // 2. Acumulamos el texto en la variable
            resultado += clave + "=" + filtrado.get(clave).toString() + "\n";
        }
        return resultado; // 3. Devolvemos el texto acumulado (ya no es null)
    }
    
    // 3. subMap 
    public String filtrarRangoCliente(Integer primero, Integer ultimo) {
        SortedMap<Integer, Cliente> filtrado = lista.subMap(primero, ultimo);
        String resultado = "";
        for (Integer clave : filtrado.keySet()) {
            resultado += clave + "=" + filtrado.get(clave).toString() + "\n";
        }
        return resultado;
    }
        
    // 4. lowerKey
    public String obtenerAnteriorCliente(Integer numero) {
        Integer anterior = lista.lowerKey(numero);
        if (anterior != null) {
            return "Cliente anterior: " + anterior;
        }
        return "No hay anterior";
    }
        
    // 5. descendingMap
    public String obtenerClientesInvertido() {
        SortedMap<Integer, Cliente> invertido = lista.descendingMap();
        String resultado = "";
        for (Integer clave : invertido.keySet()) {
            resultado += clave + "=" + invertido.get(clave).toString();
        }
        return resultado;
    }
        
    // 6. pollFirstEntry
    public String extraerClienteMasViejo() {   
        Map.Entry<Integer, Cliente> extraido = lista.pollFirstEntry();
        return "Extraido y borrado: " + extraido.getKey() + " - " + extraido.getValue().toString();
    }
}