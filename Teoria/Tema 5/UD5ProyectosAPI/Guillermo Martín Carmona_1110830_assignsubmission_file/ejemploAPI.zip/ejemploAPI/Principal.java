package ejemploAPI;

import utilidades.Lectura;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CRUDclientes crud = new CRUDclientes();
        EstadisticasClientes consultas = new EstadisticasClientes(crud.getLista());

        int opcion, num, num1;
        String tipo, nombre;

        crud.registrarCliente(100, new Cliente("Laura Gómez", "VIP"));
        crud.registrarCliente(101, new Cliente("Carlos Ruiz", "Habitual"));
        crud.registrarCliente(102, new Cliente("Marta Díaz", "Nuevo"));

        do {
            System.out.println("\nMENÚ");
            System.out.println("1. Nuevo cliente");
            System.out.println("2. Mostrar clientes");
            System.out.println("3. Actualizar tipo cliente");
            System.out.println("4. Eliminar cliente");
            System.out.println("5. Ver socio más viejo (firstKey)");
            System.out.println("6. Filtrar (tailMap)");
            System.out.println("7. Filtrar por rango (subMap)");
            System.out.println("8. Buscar socio anterior a uno (lowerKey)");
            System.out.println("9. Ver clientes invertidos (descendingMap)");
            System.out.println("10. Extraer el cliente más antiguo (pollFirstEntry)");
            System.out.println("0. Salir");
            opcion = Lectura.datoInt();

            switch (opcion) {
                case 1:
                    System.out.print("Número de cliente: ");
                    num = Lectura.datoInt();
                    System.out.print("Nombre: ");
                    nombre = Lectura.dato();
                    System.out.print("Categoría: ");
                    tipo = Lectura.dato();
                    crud.registrarCliente(num, new Cliente(nombre, tipo));
                    System.out.println("Cliente registrado");
                    break;
                    
                case 2:
                    System.out.println(crud.obtenerClientes());
                    break;
                    
                case 3:
                    System.out.print("Socio a actualizar: ");
                    num = Lectura.datoInt();
                    System.out.print("Nueva tipo: ");
                    tipo = Lectura.dato();
                    if (crud.modificarTipo(num, tipo)) {
                        System.out.println("Actualizado.");
                    } else {
                        System.out.println("Cliente no existe.");
                    }
                    break;
                    
                case 4:
                    System.out.print("Cliente a borrar: ");
                    num = Lectura.datoInt();
                    if (crud.eliminarCliente(num)) {
                        System.out.println("Borrado correctamente.");
                    } else {
                        System.out.println("Cliente no encontrado.");
                    }
                    break;
                    
                case 5:
                    System.out.println(consultas.obtenerClienteMasViejo());
                    break;
                    
                case 6:
                    System.out.print("Mostrar desde el socio nº: ");
                    num = Lectura.datoInt();
                    System.out.println(consultas.filtrarCliente(num));
                    break;
                    
                case 7:
                    System.out.print("Número inicial: ");
                    num = Lectura.datoInt();
                    System.out.print("Número límite (no incluido): ");
                    num1 = Lectura.datoInt();
                    System.out.println(consultas.filtrarRangoCliente(num, num1));
                    break;
                    
                case 8:
                    System.out.print("Cliente anterior al nº: ");
                    num = Lectura.datoInt();
                    System.out.println(consultas.obtenerAnteriorCliente(num));
                    break;
                    
                case 9:
                    System.out.println(consultas.obtenerClientesInvertido());
                    break;
                    
                case 10:
                    System.out.println(consultas.extraerClienteMasViejo());
                    break;

                case 0:
                    System.out.println("Gracias por usar este programa...");
                    break;

                default:
                    System.out.println("Opción no válida");
                    break;
            }
        } while (opcion != 0);
    }
}	

            
      
    
