package ejemploAPI;

import java.util.TreeMap;

public class CRUDclientes {

	private TreeMap<Integer, Cliente> lista = new TreeMap<>();

    public void registrarCliente(int numeroCliente, Cliente cliente) {
        lista.put(numeroCliente, cliente);
    }
    
    public String obtenerClientes() {
        return lista.toString();
    }
    
    public boolean modificarTipo(int numeroCliente, String nuevoTipo) {
        if (lista.containsKey(numeroCliente)) {
            lista.get(numeroCliente).setTipo(nuevoTipo);
            return true;
        }
        return false;
    }
    
    public boolean eliminarCliente(int numeroCliente) {
        return lista.remove(numeroCliente) != null;
    }
    
    public TreeMap<Integer, Cliente> getLista() {
        return lista;
    }
}