package modelo;

public class Producto {

	private final int id;
	private String nombre;
	private int stock;
	private double precio;

	public Producto(int id, String nombre, int stock, double precio) {
		this.id = id;
		this.nombre = nombre;
		this.stock = stock;
		this.precio = precio;
	}

	public Producto(Producto producto) {
		this.id = producto.id;
		this.nombre = producto.nombre;
		this.stock = producto.stock;
		this.precio = producto.precio;
	}

	public int getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public int getStock() {
		return stock;
	}

	public double getPrecio() {
		return precio;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", nombre=" + nombre + ", stock=" + stock + ", precio=" + precio + "]";
	}
}
