package modelo;

public class AccionInventario {

	private String tipoAccion;
	private Producto productoAntes;
	private Producto productoDespues;
	private String descripcion;

	public AccionInventario(String tipoAccion, Producto productoAntes, Producto productoDespues,
			String descripcion) {
		this.tipoAccion = tipoAccion;
		this.productoAntes = productoAntes;
		this.productoDespues = productoDespues;
		this.descripcion = descripcion;
	}

	public String getTipoAccion() {
		return tipoAccion;
	}

	public Producto getProductoAntes() {
		return productoAntes;
	}

	public Producto getProductoDespues() {
		return productoDespues;
	}

	public String getDescripcion() {
		return descripcion;
	}

	@Override
	public String toString() {
		return "AccionInventario [tipoAccion=" + tipoAccion + ", descripcion=" + descripcion + "]";
	}
}
