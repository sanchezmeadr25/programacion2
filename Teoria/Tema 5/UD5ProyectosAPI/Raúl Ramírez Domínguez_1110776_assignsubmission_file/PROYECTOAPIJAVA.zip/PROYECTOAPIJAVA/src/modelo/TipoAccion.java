package modelo;

public class TipoAccion {

	public static String ALTA = "ALTA";
	public static String BAJA = "BAJA";
	public static String MODIFICACION = "MODIFICACION";

}