package servicio;

import dao.InventarioDAO;
import java.util.Stack;
import modelo.AccionInventario;
import modelo.Producto;
import modelo.TipoAccion;

public class GestorInventario {

	private final InventarioDAO dao;
	private final Stack<AccionInventario> historial;

	public GestorInventario() {
		dao = new InventarioDAO();
		historial = new Stack<>();
	}

	public boolean altaProducto(Producto producto) {
		boolean insertado;
		AccionInventario accion;

		insertado = dao.insertar(producto);

		if (insertado == true) {
			accion = new AccionInventario(TipoAccion.ALTA, null, new Producto(producto),
					"Alta del producto " + producto.getNombre());

			historial.push(accion);
		}

		return insertado;
	}

	public boolean eliminarProducto(int id) {
		Producto producto;
		Producto copiaProducto;
		boolean eliminado;
		AccionInventario accion;

		producto = dao.buscarPorId(id);

		if (producto == null) {
			return false;
		}

		copiaProducto = new Producto(producto);
		eliminado = dao.eliminar(id);

		if (eliminado == true) {
			accion = new AccionInventario(TipoAccion.BAJA, copiaProducto, null,
					"Eliminación del producto " + copiaProducto.getNombre());

			historial.push(accion);
		}

		return eliminado;
	}

	public boolean modificarStock(int id, int nuevoStock) {
		Producto producto;
		Producto antes;
		Producto despues;
		AccionInventario accion;

		producto = dao.buscarPorId(id);

		if (producto == null) {
			return false;
		}

		antes = new Producto(producto);
		producto.setStock(nuevoStock);
		despues = new Producto(producto);

		accion = new AccionInventario(TipoAccion.MODIFICACION, antes, despues,
				"Modificación de stock del producto " + producto.getNombre());

		historial.push(accion);

		return true;
	}

	public boolean deshacerUltimaAccion() {
		AccionInventario ultimaAccion;
		Producto producto;

		if (historial.empty() == true) {
			return false;
		}

		ultimaAccion = historial.pop();

		if (ultimaAccion.getTipoAccion().equals(TipoAccion.ALTA)) {
			dao.eliminar(ultimaAccion.getProductoDespues().getId());
		} else if (ultimaAccion.getTipoAccion().equals(TipoAccion.BAJA)) {
			dao.insertar(new Producto(ultimaAccion.getProductoAntes()));
		} else if (ultimaAccion.getTipoAccion().equals(TipoAccion.MODIFICACION)) {
			producto = dao.buscarPorId(ultimaAccion.getProductoDespues().getId());

			if (producto != null) {
				producto.setStock(ultimaAccion.getProductoAntes().getStock());
			}
		}

		return true;
	}

	public AccionInventario verUltimaAccion() {
		if (historial.empty() == true) {
			return null;
		}

		return historial.peek();
	}

	public int totalAccionesPendientesDeshacer() {
		return historial.size();
	}

	public int buscarAccion(AccionInventario accion) {
		return historial.search(accion);
	}

	public InventarioDAO getDao() {
		return dao;
	}
}