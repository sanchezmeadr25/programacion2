package principal;

import modelo.Producto;
import servicio.GestorInventario;
import utilidades.Leer;

public class Principal {

	public static void main(String[] args) {

		/*
		 * ENUNCIADO DEL EJERCICIO: Una tienda necesita una aplicación de consola para
		 * gestionar productos de su inventario. El sistema permitirá dar de alta,
		 * eliminar, modificar y listar productos. Además, se implementará una
		 * funcionalidad para deshacer la última operación realizada utilizando una pila
		 * (Stack).
		 */

		GestorInventario gestor;
		int opcion;

		int id;
		String nombre;
		int stock;
		double precio;

		int idEliminar;
		int idModificar;
		int nuevoStock;

		Producto nuevoProducto;

		gestor = new GestorInventario();

		do {
			System.out.println("\nMENÚ DE INVENTARIO");
			System.out.println("1. Alta de producto");
			System.out.println("2. Eliminar producto");
			System.out.println("3. Modificar stock");
			System.out.println("4. Listar productos");
			System.out.println("5. Ver última acción");
			System.out.println("6. Deshacer última acción");
			System.out.println("7. Mostrar número de acciones guardadas");
			System.out.println("0. Salir");
			System.out.print("Elige una opción: ");

			opcion = Leer.datoInt();

			switch (opcion) {

			case 1:
				System.out.print("Introduce el id: ");
				id = Leer.datoInt();

				System.out.print("Introduce el nombre: ");
				nombre = Leer.dato();

				System.out.print("Introduce el stock: ");
				stock = Leer.datoInt();

				System.out.print("Introduce el precio: ");
				precio = Leer.datoDouble();

				nuevoProducto = new Producto(id, nombre, stock, precio);

				if (gestor.altaProducto(nuevoProducto)) {
					System.out.println("Producto dado de alta correctamente.");
				} else {
					System.out.println("Ya existe un producto con ese id.");
				}
				break;

			case 2:
				System.out.print("Introduce el id del producto a eliminar: ");
				idEliminar = Leer.datoInt();

				if (gestor.eliminarProducto(idEliminar)) {
					System.out.println("Producto eliminado correctamente.");
				} else {
					System.out.println("No existe ningún producto con ese id.");
				}
				break;

			case 3:
				System.out.print("Introduce el id del producto: ");
				idModificar = Leer.datoInt();

				System.out.print("Introduce el nuevo stock: ");
				nuevoStock = Leer.datoInt();

				if (gestor.modificarStock(idModificar, nuevoStock)) {
					System.out.println("Stock modificado correctamente.");
				} else {
					System.out.println("No existe ningún producto con ese id.");
				}
				break;

			case 4:
				if (gestor.getDao().listar().isEmpty()) {
					System.out.println("No hay productos en el inventario.");
				} else {
					System.out.println("\n--- LISTADO DE PRODUCTOS ---");
					for (Producto p : gestor.getDao().listar()) {
						System.out.println(p);
					}
				}
				break;

			case 5:
				if (gestor.verUltimaAccion() == null) {
					System.out.println("No hay acciones registradas.");
				} else {
					System.out.println("Última acción:");
					System.out.println(gestor.verUltimaAccion());
				}
				break;

			case 6:
				if (gestor.deshacerUltimaAccion()) {
					System.out.println("Acción deshecha correctamente.");
				} else {
					System.out.println("No hay acciones para deshacer.");
				}
				break;

			case 7:
				System.out.println("Acciones en la pila: " + gestor.totalAccionesPendientesDeshacer());
				break;

			case 0:
				System.out.println("Programa finalizado.");
				break;

			default:
				System.out.println("Opción no válida.");
			}

		} while (opcion != 0);
	}
}