package dao;

import java.util.ArrayList;
import modelo.Producto;

public class InventarioDAO {

	private ArrayList<Producto> productos;

	public InventarioDAO() {
		productos = new ArrayList<Producto>();
	}

	public boolean insertar(Producto producto) {
		if (buscarPorId(producto.getId()) != null) {
			return false;
		}

		productos.add(producto);
		return true;
	}

	public Producto buscarPorId(int id) {
		for (int i = 0; i < productos.size(); i++) {
			if (productos.get(i).getId() == id) {
				return productos.get(i);
			}
		}
		return null;
	}

	public ArrayList<Producto> listar() {
		return productos;
	}

	public boolean eliminar(int id) {
		Producto producto = buscarPorId(id);

		if (producto != null) {
			productos.remove(producto);
			return true;
		}

		return false;
	}
}