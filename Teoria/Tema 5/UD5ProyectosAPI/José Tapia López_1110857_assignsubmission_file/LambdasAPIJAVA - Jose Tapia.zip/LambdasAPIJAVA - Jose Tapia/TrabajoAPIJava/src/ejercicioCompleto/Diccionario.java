package ejercicioCompleto;

import java.util.List;
import java.util.Iterator;


public class Diccionario {

	// ATRIBUTOS
	
	private List <Palabra> diccionario;

	
	
	// METODOS 
	
	public List<Palabra> getDiccionario() {
		return diccionario;
	}


	public void setDiccionario(List<Palabra> diccionario) {
		this.diccionario = diccionario;
	}


	public Diccionario(List<Palabra> diccionario) {
		super();
		this.diccionario = diccionario;
	}


	public Palabra findByName (String palabraBuscada) {
		
		Iterator <Palabra> it = diccionario.iterator(); 
		
		while (it.hasNext()) {
			
			Palabra analizar = it.next();
			
			if (analizar.getNombreIngles().equalsIgnoreCase(palabraBuscada))
				return analizar;
		}
		return null;
	}
	
	
	// CRUD
	
	public void agregarPalabra (Palabra newPalabra) {
		
		 diccionario.add(newPalabra);
	}
	
	
	public void modificarPalabra (String palabraBuscada, String newSignificado) {
		
		 findByName(palabraBuscada).setSignificado(newSignificado);
		
	}
	
	public boolean eliminarPalabra (String palabraBuscada) {
		
		return diccionario.remove(findByName(palabraBuscada));
		
		
	}
	
	public void mostrarPalabras () {
		
		int n = 1;
	
		for (Palabra pal : diccionario ) {
			
			pal.mostrarPalabra(n);
			n++;
		}
		
	}
	
	// TRAER LISTA COMPLETA
	
	
	
	
}
