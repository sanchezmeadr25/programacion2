package ejercicioCompleto;

public class Palabra {

	// ATRIBUTOS
	
	private int id;
	private String nombreIngles;
	private String significado;
	
	
	public Palabra(int id, String nombreIngles, String significado) {
		super();
		this.id = id;
		this.nombreIngles = nombreIngles;
		this.significado = significado;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNombreIngles() {
		return nombreIngles;
	}


	public void setNombreIngles(String nombreIngles) {
		this.nombreIngles = nombreIngles;
	}


	public String getSignificado() {
		return significado;
	}


	public void setSignificado(String significado) {
		this.significado = significado;
	}
	
	// METODOS 
	
	public void mostrarPalabra(int n) {
		
		System.out.println("\nPalabra Num."+n);
		System.out.println("Palabra: "+this.nombreIngles);
		System.out.println("Significado: "+this.significado);
		
	}
	
	
	
	
	
}
