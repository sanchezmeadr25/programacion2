package ejercicioCompleto;

import java.util.ArrayList;
import java.util.List;

import utilidades.Leer;

public class Principal {
	public static void main(String[] args) {
		
		
		/*ENUNCIADO DEL PROBLEMA
		 * Desarrolla una aplicación interactiva por consola que funcione como un gestor de diccionario bilingüe (Inglés-Español). 
		 * El programa debe mostrar un menú principal que permita al usuario ver todas las palabras registradas, añadir nuevos términos 
		 * con su traducción, y modificar o eliminar palabras existentes. Además, debe incluir opciones de búsqueda avanzada para que el 
		 * usuario pueda filtrar el catálogo según diferentes criterios: por un lado, buscando palabras que comiencen por un texto específico;
		 *  y por otro, filtrando aquellas que alcancen una longitud mínima de letras pero excluyendo las que empiecen por una letra determinada.*/
		
		
		// DECLARACIÓN DE VARIABLES
		
		int opcion;
		int id = 0;
		String palabraEscogida;
		String significadoEscogido, nuevoSignificado;
		int minimoLetras;
		
		// INSTANCIA DE OBJETOS
		
		Palabra p1 = new Palabra (1, "Desk", "Escritorio");
		Palabra p2 = new Palabra (2, "Apple", "Manzana");
		Palabra p3 = new Palabra (3, "Disk", "Disco duro");

		id = 4; // dado que instanciamos 3 objetos mágicamente
		
		List <Palabra> listado = new ArrayList<Palabra>();
		
		Diccionario diccionario = new Diccionario(listado);
		
		diccionario.agregarPalabra(p1);
		diccionario.agregarPalabra(p3);
		diccionario.agregarPalabra(p2);
		
		LogicaDiccionario logica = new LogicaDiccionario(diccionario);
		
		
		System.out.println("Bienvenido al programa. ¿Qué quieres probar?");
		
		do {
			System.out.println("\nEscoja entre las opciones:");
			System.out.println("1 para mostrar");
			System.out.println("2 para agregar");
			System.out.println("3 para modificar");
			System.out.println("4 para borrar");
			System.out.println("5 para filtrar por letras");
			System.out.println("6 para filtrar por número de caracteres");
			
			System.out.println("0 para salir");
			
			opcion = Leer.datoInt();
			
			switch (opcion) {
			
				case 1:
				
					System.out.println("Escogiste mostrar.");
					diccionario.mostrarPalabras();
					
					break;
					
				case 2:
					
					System.out.println("Escogiste agregar.");
					
					
					System.out.println("Dime la palabra:");
					palabraEscogida = Leer.dato();
					
					System.out.println("Ahora dime su significado:");
					significadoEscogido = Leer.dato();
					
					diccionario.agregarPalabra(new Palabra (id, palabraEscogida, significadoEscogido));
			
					id ++;
					
					System.out.println("\n¡Palabra agregada correctamente!");
					break;
					
					
				case 3: 
					System.out.println("Vamos a modificar palabras, dime la palabra que buscas:");
					
					palabraEscogida = Leer.dato();
					
					
					
					if (diccionario.findByName(palabraEscogida) != null) { 
						System.out.println("\nAhora dime la nueva traducción:");
						nuevoSignificado = Leer.dato();
						
						diccionario.modificarPalabra(palabraEscogida, nuevoSignificado);
						
						System.out.println("\n¡Palabra modificada correctamente!");
					}else {
						System.err.println("Palabra no encontrada, vuelve a intentarlo.");
					}
					
					break;
					
					
					
					
				case 4: 
					System.out.println("Vamos a eliminar la palabra del diccionario, dime cuál deseas eliminar:");
					
					palabraEscogida = Leer.dato();
					
					if (diccionario.findByName(palabraEscogida) != null) { 
						diccionario.eliminarPalabra(palabraEscogida);
						
						System.out.println("\n¡Palabra eliminada correctamente!");

					}else {
						System.err.println("Palabra no encontrada, vuelve a intentarlo.");
					}
					
					break;
					
				case 5:
					System.out.println("Estás en la sección de filtrado por letras. Introduce las letras por las que empieza tu palabra:");
					
					System.out.println("Indica con qué letra o conjunto de letras empieza:");
					palabraEscogida = Leer.dato();
					
					logica.mostrarListas(logica.filtrarPorLetras(palabraEscogida));
					
					break;
					
				case 6:
					System.out.println("En esta sección vamos a filtrar por el número de letras y por qué letra no quieres que empiece la palabra.");
					
					System.out.println("¿Me podrías decir cuánto es el mínimo de letras?");
					minimoLetras = Leer.datoInt();
					
					System.out.println("¿Me podrías decir qué letra/conjunto quieres evitar?");
					
					palabraEscogida=Leer.dato();
					
					logica.mostrarListas(logica.filtrarPorLongitudYLetras(minimoLetras, palabraEscogida));
					
					break;
					
				case 0: 
					System.out.println("Saliendo del programa.");
					break;
					
				default:
					System.err.println("Has introducido un número erróneo, vuelve a intentarlo.");
					break;
					
			}
			
			
		}while (opcion != 0);
		
		System.out.println("Muchas gracias por utilizar el programa.");
	}
}