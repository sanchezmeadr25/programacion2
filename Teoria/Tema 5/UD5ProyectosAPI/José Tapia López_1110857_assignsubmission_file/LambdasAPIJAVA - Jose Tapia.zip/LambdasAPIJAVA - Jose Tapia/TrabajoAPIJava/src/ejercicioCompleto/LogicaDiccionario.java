package ejercicioCompleto;

import java.util.ArrayList;
import java.util.List;
import java.util.function.*;


public class LogicaDiccionario {
	
	private Diccionario logicaDicc;
	
	public LogicaDiccionario(Diccionario logicaDicc) {
		super();
		this.logicaDicc = logicaDicc;
	}


	/*EN ESTA SECCION VAMOS A CENTRARNOS EN LA LOGICA DE NEGOCIO PERO ENFOCADA EN LOS USOS CON LAMBDAS*/ 
	
	public List<Palabra> filtrarPorLetras (String filtro) {
		
		List<Palabra> palabrasFiltradas = new ArrayList<Palabra>();
		
		Predicate <Palabra> filtradoLetras = palabra -> palabra.getNombreIngles().startsWith(filtro); 
		
		logicaDicc.getDiccionario().stream()
			.filter(filtradoLetras)
			.forEach(palabra -> palabrasFiltradas.add(palabra));
		
		return palabrasFiltradas;	
		
	}
	
	public List<Palabra> filtrarPorLongitudYLetras (int longitud, String filtro) {
		
		List<Palabra> palabrasFiltradas = new ArrayList<Palabra>();
		
		Predicate <Palabra> filtradoLetras = palabra -> palabra.getNombreIngles().startsWith(filtro); //estas seran las letras que vayamos a ignorar
		Predicate<Palabra> longitudPalabra = palabra -> palabra.getNombreIngles().length() >= longitud;
		
		logicaDicc.getDiccionario().stream()
		.filter(longitudPalabra.and(filtradoLetras).negate())
		.forEach(palabra -> palabrasFiltradas.add(palabra));
	
	return palabrasFiltradas;	
		
	}
	
	
	public void mostrarListas (List <Palabra> listado) {
		
		int[] indice = {1};
	    
	    listado.stream()
	        .forEach(palabra -> {
	            palabra.mostrarPalabra(indice[0]); 
	            indice[0]++; 
	            
	        });
	}
	
}
