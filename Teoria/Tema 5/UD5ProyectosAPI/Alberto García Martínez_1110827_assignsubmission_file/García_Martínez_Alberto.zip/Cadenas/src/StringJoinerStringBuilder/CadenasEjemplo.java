package StringJoinerStringBuilder;

import java.util.StringJoiner;

public class CadenasEjemplo {

    public static void main(String[] args) {

        System.out.println("STRINGBUILDER\n");

        //añadir texto al final
        StringBuilder sb = new StringBuilder();
        sb.append("Hola");
        sb.append(" ");
        sb.append("mundo");
        sb.append(2026);
        System.out.println("append: " + sb);

        //añadir caracter por codigo Unicode
        sb = new StringBuilder("Letra: ");
        sb.appendCodePoint(65);
        sb.appendCodePoint(66);
        System.out.println("appendCodePoint: " + sb);

        //espacio reservado internamente
        sb = new StringBuilder();
        System.out.println("capacity vacio: " + sb.capacity());
        sb.append("12345678901234567890");
        System.out.println("capacity despues de texto largo: " + sb.capacity());

        //letra en una posicion
        sb = new StringBuilder("Gato");
        System.out.println("charAt(0): " + sb.charAt(0));
        System.out.println("charAt(3): " + sb.charAt(3));

        //codigo Unicode de una posicion
        sb = new StringBuilder("ABC");
        System.out.println("codePointAt(0): " + sb.codePointAt(0)); 
        System.out.println("codePointAt(1): " + sb.codePointAt(1)); 

        //codigo Unicode antes de una posicion
        sb = new StringBuilder("ABC");
        System.out.println("codePointBefore(1): " + sb.codePointBefore(1));
        System.out.println("codePointBefore(3): " + sb.codePointBefore(3));

        //cuantos codigos Unicode entre dos posiciones
        sb = new StringBuilder("Hola");
        System.out.println("codePointCount(0,4): " + sb.codePointCount(0, 4));

        //borrar un trozo
        sb = new StringBuilder("Hola mundo");
        sb.delete(0, 5); 
        System.out.println("delete(0,5): " + sb);

        //borrar una sola letra
        sb = new StringBuilder("Hola");
        sb.deleteCharAt(0);
        System.out.println("deleteCharAt(0): " + sb);

        //asegurar espacio minimo
        sb = new StringBuilder();
        System.out.println("capacity antes: " + sb.capacity());
        sb.ensureCapacity(100);
        System.out.println("capacity despues de ensureCapacity(100): " + sb.capacity());

        //copiar trozo a un array de char
        sb = new StringBuilder("Programacion");
        char[] letras = new char[4];
        sb.getChars(0, 4, letras, 0);
        System.out.println("getChars: " + new String(letras));

        //buscar primera aparicion
        sb = new StringBuilder("perro gato perro");
        System.out.println("indexOf perro: " + sb.indexOf("perro"));
        System.out.println("indexOf gato: " + sb.indexOf("gato"));

        //insertar en una posicion
        sb = new StringBuilder("Hola mundo");
        sb.insert(5, "cruel ");
        System.out.println("insert: " + sb);

        //buscar ultima aparicion
        sb = new StringBuilder("perro gato perro");
        System.out.println("lastIndexOf perro: " + sb.lastIndexOf("perro"));

        //largo del texto
        sb = new StringBuilder("Java");
        System.out.println("length: " + sb.length());

        //saltar posiciones Unicode
        sb = new StringBuilder("ABCDE");
        int pos = sb.offsetByCodePoints(0, 3);
        System.out.println("offsetByCodePoints(0,3): " + pos);
        System.out.println("letra en esa posicion: " + sb.charAt(pos));

        //sustituir un trozo ---
        sb = new StringBuilder("Hola mundo");
        sb.replace(5, 10, "Java"); 
        System.out.println("replace: " + sb);

        //darle la vuelta
        sb = new StringBuilder("Hola");
        sb.reverse();
        System.out.println("reverse: " + sb);

        //cambiar una letra
        sb = new StringBuilder("Gato");
        sb.setCharAt(0, 'P');
        System.out.println("setCharAt: " + sb);

        //cambiar el largo
        sb = new StringBuilder("Hola mundo");
        sb.setLength(4);
        System.out.println("setLength(4): " + sb);

        //extraer trozo como CharSequence
        sb = new StringBuilder("Programacion");
        CharSequence trozo = sb.subSequence(0, 4);
        System.out.println("subSequence(0,4): " + trozo);

        //extraer trozo como String
        sb = new StringBuilder("Programacion");
        String parte = sb.substring(0, 4);
        System.out.println("substring(0,4): " + parte);
        String resto = sb.substring(4);
        System.out.println("substring(4): " + resto);

        //convertir a String
        sb = new StringBuilder();
        sb.append("Texto").append(" final");
        String resultado = sb.toString();
        System.out.println("toString: " + resultado);

        //liberar memoria sobrante
        sb = new StringBuilder(100);
        sb.append("Hola");
        System.out.println("capacity antes de trim: " + sb.capacity());
        sb.trimToSize();
        System.out.println("capacity despues de trim: " + sb.capacity());

        System.out.println("\nSTRINGJOINER\n");

        //Constructor con separador
        StringJoiner sj = new StringJoiner(", ");
        sj.add("manzana");
        sj.add("pera");
        sj.add("platano");
        System.out.println("basico: " + sj);

        //Constructor con separador, prefijo y sufijo
        sj = new StringJoiner(", ", "[", "]");
        sj.add("rojo");
        sj.add("verde");
        sj.add("azul");
        System.out.println("con prefijo y sufijo: " + sj);

        //añadir elementos encadenado
        sj = new StringJoiner(" - ");
        sj.add("uno").add("dos").add("tres");
        System.out.println("add encadenado: " + sj);

        //unir dos StringJoiner
        StringJoiner frutas = new StringJoiner(", ");
        frutas.add("manzana").add("pera");

        StringJoiner verduras = new StringJoiner("; ");
        verduras.add("lechuga").add("tomate");

        frutas.merge(verduras);
        System.out.println("merge: " + frutas);

        //texto cuando esta vacio
        sj = new StringJoiner(", ", "[", "]");
        sj.setEmptyValue("VACIO");
        System.out.println("vacio con setEmptyValue: " + sj);
        sj.add("algo");
        System.out.println("ya no vacio: " + sj);

        //largo del resultado final
        sj = new StringJoiner(", ", "(", ")");
        sj.add("a").add("bb").add("ccc");
        System.out.println("contenido: " + sj); 
        System.out.println("length: " + sj.length());

        //obtener el String final
        sj = new StringJoiner(" | ");
        sj.add("Java").add("Python").add("C++");
        String textoFinal = sj.toString();
        System.out.println("toString: " + textoFinal); 
    }
}
