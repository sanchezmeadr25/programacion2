package ejemploVar;

import utilidades.Leer;

public class Principal {

	public static void main(String[] args) {

		var ges = new GestionAlumnos();
		var opcion = 0;

		do {

			System.out.println("1. Añadir alumno");
			System.out.println("2. Mostrar alumnos");
			System.out.println("3. Buscar alumno");
			System.out.println("4. Actualizar alumno");
			System.out.println("5. Eliminar alumno");
			System.out.println("0. Salir");

			System.out.print("Elige opción: ");
			opcion = Leer.datoInt();

			switch (opcion) {

			case 1:
				System.out.print("ID: ");
				var id = Leer.datoInt();

				System.out.print("Nombre: ");
				var nombre = Leer.dato();

				System.out.print("Edad: ");
				var edad = Leer.datoInt();
				var alumno = new Alumno(id, nombre, edad);

				ges.addAlumno(alumno);
				System.out.println("Alumno añadido");
				break;

			case 2:
				System.out.println("Lista de alumnos:");
				ges.mostrarAlumnos();
				break;

			case 3:
				System.out.print("ID a buscar: ");
				var idBuscar = Leer.datoInt();

				var alum = ges.buscarPorId(idBuscar);

				if (alum != null) {
					System.out.println("Encontrado: " + alum);
				} else {
					System.out.println("No encontrado");
				}
				break;

			case 4:
				System.out.print("ID a actualizar: ");
				var idAct = Leer.datoInt();

				System.out.print("Nuevo nombre: ");
				var nuevoNombre = Leer.dato();

				System.out.print("Nueva edad: ");
				var nuevaEdad = Leer.datoInt();

				ges.actualizarAlumno(idAct, nuevoNombre, nuevaEdad);
				System.out.println("Alumno actualizado");
				break;

			case 5:
				System.out.print("ID a eliminar: ");
				var idDel = Leer.datoInt();

				ges.eliminarAlumno(idDel);
				System.out.println("Alumno eliminado (si existía)");
				break;

			case 0:
				System.out.println("Saliendo...");
				break;

			default:
				System.out.println("Opción inválida");
				break;
			}

		} while (opcion != 0);
	}
}