package ejemploVar;

import java.util.ArrayList;
import java.util.List;

public class GestionAlumnos {

	private List<Alumno> lista = new ArrayList<>();
	

	public void addAlumno(Alumno alumno) {
		lista.add(alumno);
	}

	public void mostrarAlumnos() {
		for (var alumno : lista) {
			System.out.println(alumno);
		}
	}

	public Alumno buscarPorId(int id) {
		for (var alumno : lista) {
			if (alumno.getId() == id) {
				return alumno;
			}
		}
		return null;
	}

	public void actualizarAlumno(int id, String nombre, int edad) {
		var alumno = buscarPorId(id);

		if (alumno != null) {
			alumno.setNombre(nombre);
			alumno.setEdad(edad);
		}
	}

	public void eliminarAlumno(int id) {
		var iterator = lista.iterator();

		while (iterator.hasNext()) {
			var alumno = iterator.next();

			if (alumno.getId() == id) {
				iterator.remove();
				return;
			}
		}
	}

}
