package tutorial;

public class Descarga implements Runnable { // Cada archivo que cree será el encargado de descargarse a si mismo

	private String nombre;
	private double tamanioTotal;
	private double porcentajeDescargado;
	private boolean estado;
	private String id;
	// A cada descarga se le asigna un hilo propio para que sepa con cual tiene que
	// trabajar
	private Thread hilo;

	public Descarga(String nombre, double tamanioTotal, double porcentajeDescargado, boolean estado, String id) {
		super();
		this.nombre = nombre;
		this.tamanioTotal = tamanioTotal;
		this.porcentajeDescargado = porcentajeDescargado;
		this.estado = estado;
		this.id = id;
	}

	public Thread getHilo() {
		return hilo;
	}

	public void setHilo(Thread hilo) {
		this.hilo = hilo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getTamanioTotal() {
		return tamanioTotal;
	}

	public void setTamanioTotal(double tamanioTotal) {
		this.tamanioTotal = tamanioTotal;
	}

	public double getPorcentajeDescargado() {
		return porcentajeDescargado;
	}

	public void setPorcentajeDescargado(double porcentajeDescargado) {
		this.porcentajeDescargado = porcentajeDescargado;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Descarga [nombre=" + nombre + ", tamanioTotal=" + tamanioTotal + ", porcentajeDescargado="
				+ porcentajeDescargado + ", estado=" + estado + ", id= " + id + "]";
	}

	// Es el metodo principal, el cual simula la descarga. Se hace simulando que
	// cada medio minuto el porcentaje descargado se sume en 0.5.
	// Utiliza try catch y funciona de la siguiente manera:
	// El programa prueba a dormir el hilo pero en cada iteración, cuando en una de
	// estas
	// iteraciones el programa ve que no puede mandar al hilo a dormir, por que este
	// ha sido interrumpido, entra en el catch. El break del catch es fundamental
	// para que pueda salir del bucle
	@Override
	public void run() {
		while (porcentajeDescargado <= tamanioTotal) {
			porcentajeDescargado += 0.5;
			try {
				Thread.sleep(3000);
				estado = true;
			} catch (InterruptedException ie) {
				System.out.println("Descarga: " + nombre + " cancelada al: " + porcentajeDescargado + "%");
				estado = false;
				break;
			}

		}
		estado = false;

	}

	// Interrumpe la descarga a partir del metodo interrupt
	public void detenerDescarga() {

		if (hilo != null) {

			hilo.interrupt();

		}

	}

}
