package tutorial;

import java.util.ArrayList;
import java.util.List;

public class GestorDescargas {

	// Debido a la concurrencia, el uso de las colecciones clasicas no son seguras
	// para los hilos
	private List<Descarga> descargas;

	public GestorDescargas(List<Descarga> descargas) {
		super();
		this.descargas = descargas;
	}

	public List<Descarga> getDescargas() {
		return descargas;
	}

	public void setDescargas(List<Descarga> descargas) {
		this.descargas = descargas;
	}

	// Create. Añade la descargas a la lista a partir de un objeto pasado como
	// parametro, ademas de iniciar y asignar el hilo a
	// dicha descarga
	// El synchronized se utiliza para que los hilos no tengan problemas con la
	// concurrencia
	public synchronized void add(Descarga d) {

		Thread hilo = new Thread(d);
		d.setHilo(hilo);
		descargas.add(d);
		hilo.start();

	}

	// Read. Metodo simplón con foreach para mostrar todas las descargas que se
	// están realizando
	public void read() {
		for (Descarga descarga : descargas) {
			System.out.println(descarga);
		}
	}

	// Update.
	// Este metodo en realidad se podría simplificar bastante, pero he
	// decidido crear un pequeño algoritmo para que se pueda buscar tanto por id
	// como por nombre y asi utilizar los dos metodos en un solo metodo. Los returns
	// devuelven un int que actuan como una especie de booleano pero de tres
	// estados.
	// Devuelve 1 o 0 si la descarga ha sido exitosa y -1 si ha sido un fracaso
	public int update(String name, String id) {
		Descarga d = null;
		if (filtro(id, name) == 0) {
			d = finbyID(id);
			if (d != null) {
				d.detenerDescarga();
				return 1;
			}
		} else if (filtro(id, name) == 1) {
			d = findbyName(name);
			if (d != null) {
				d.detenerDescarga();
				return 0;
			}
		}
		return -1;
	}

	// Delete. El metodo usa el mismo algoritmo que en update, para aprovecharlo.
	public int delete(String name, String id) {
		Descarga d = null;
		if (filtro(id, name) == 0) {
			d = finbyID(id);
			if (d != null) {
				d.detenerDescarga();
				descargas.remove(d);
				return 1;
			}
		} else if (filtro(id, name) == 1) {
			d = findbyName(name);
			if (d != null) {
				d.detenerDescarga();
				descargas.remove(d);
				return 0;
			}
		}
		return -1;
	}

	// findbyid. Con el String que se le pasa por parametro el foreach se encarga de
	// buscar hasta encontrar la descarga que tenga el mismo id y luego devolverlo y
	// detener la busqueda
	public Descarga finbyID(String id) {
		for (Descarga descarga : descargas) {
			if (id.equalsIgnoreCase(descarga.getId())) {
				return descarga;
			}
		}
		return null;
	}

	// findbyname.
	public Descarga findbyName(String name) {
		for (Descarga descarga : descargas) {
			if (name.equalsIgnoreCase(descarga.getNombre().toLowerCase())) {
				return descarga;
			}
		}
		return null;
	}

	// Mostrar
	public void mostrarDescarga(String id, String nombre) {

		if (filtro(id, nombre) == 1) {
			Descarga d = findbyName(nombre);
			System.out.println(d);
		} else if (filtro(id, nombre) == 0) {
			Descarga d = finbyID(id);
			System.out.println(d);
		} else {
			System.out.println("No se encuentra el archivo ");

		}

	}

	// El miniAlgoritmo de filtrado con tres estados que se encarga de filtrar para
	// alternar
	// entre id que devuelve 0, nombre que devuelve 1, o en el peor caso, nada que
	// devuelve -1
	public int filtro(String id, String nombre) {

		if (id.isBlank()) {

			return 1;

		} else if (nombre.isBlank()) {

			return 0;

		} else {

			return -1;

		}

	}

	// DescargaRealizadas. Un metodo el cual valora si el archivo ha terminado de
	// descargarse y lo mete en una nueva lista de descargas realizadas
	public List<Descarga> downloaded() {
		List<Descarga> listAux = new ArrayList<Descarga>();
		for (Descarga descarga : descargas) {
			if (descarga.getPorcentajeDescargado() >= descarga.getTamanioTotal()) {
				listAux.add(descarga);
			}
		}
		return listAux;

	}

	public void mostrarDescargas(List<Descarga> listAux) {
		for (Descarga descarga : listAux) {
			System.out.println(descarga);
		}

	}

}
