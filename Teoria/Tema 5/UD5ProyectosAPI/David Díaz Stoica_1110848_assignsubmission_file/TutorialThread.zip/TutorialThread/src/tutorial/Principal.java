package tutorial;

import java.util.ArrayList;
import java.util.List;

import utilidades.Leer;

public class Principal {

	public static void main(String[] args) {

		/*
		 * Eres el creador de un gestor de descargas estilo uTorrent o un navegador web.
		 * El usuario puede poner a descargar varios archivos pesados a la vez, y el
		 * programa no debe bloquearse mientras se descargan. El usuario puede: -añadir
		 * una nueva descarga (predefinida o creada por el) -Ver las descargas que se
		 * están realizando en el momento -Ver las descargas ya realizadas -Buscar y
		 * poder detener la descarga que quiera.Además la busqueda esta lo mas
		 * generalizada posible para no tener que repetir el mismo metodo dos veces con
		 * diferentes atributos -borrar una descarga
		 */

		String nombre, id, buscarNombre, buscarId, yesno;
		int tamanio = 0, opcion, opcion2;
		Descarga d1 = new Descarga("Ubuntu", 25, 0, false, "292939p");
		Descarga d2 = new Descarga("LeagueOfLegends", 1700, 1700, false, "83949o");
		Descarga d;
		List<Descarga> listaDescarga = new ArrayList<Descarga>();
		GestorDescargas gd = new GestorDescargas(listaDescarga);

		do {
			System.out.println("\n\tdescargasFiables");
			System.out.println("-----------------------------");
			System.out.println("\t\tMenú");
			System.out.println("-----------------------------");
			System.out.println("Pulse 1 para añadir una nueva descarga");
			System.out.println("Pulse 2 para ver las descargas en curso");
			System.out.println("Pulse 3 para ver las descargas anteriores");
			System.out.println("Pulse 4 para buscar una descarga");
			System.out.println("Pulse 5 para borrar una descarga");
			System.out.println("Pulse 0 para salir");
			opcion = Leer.datoInt();

			switch (opcion) {
			case 1:

				System.out.println("Pulse 1 para descargar UbuntuServer");
				System.out.println("Pulse 2 para descargar LeagueOfLegends ");
				System.out.println("Pulse 3 para descargar cualquier otra cosa");
				System.out.println("Pulse cualquier otro botón para salir");
				opcion2 = Leer.datoInt();
				switch (opcion2) {
				case 1:
					System.out.println("Comenzando la descarga de Ubuntu...");
					gd.add(d1);
					break;
				case 2:
					System.out.println("Comenzando la descarga de LoL...");
					gd.add(d2);
					break;

				case 3:
					System.out.println("Nombre del programa");
					nombre = Leer.dato();
					System.out.println("Tamaño del programa");
					tamanio = Leer.datoInt();
					System.out.println("Id");
					id = Leer.dato();
					d = new Descarga(nombre, tamanio, 0, false, id);
					gd.add(d);
					break;
				default:
					break;
				}

				break;
			case 2:
				gd.read();

				break;
			case 3:
				gd.mostrarDescargas(gd.downloaded());

				break;
			case 4:
				buscarId = "";
				buscarNombre = "";
				System.out.println("Pulse 1 para buscar por nombre ");
				System.out.println("Pulse 2 para buscar por id");
				opcion2 = Leer.datoInt();
				switch (opcion2) {
				case 1:
					System.out.println("Escriba el nombre");
					buscarNombre = Leer.dato();
					gd.mostrarDescarga(buscarId, buscarNombre);
					System.out.println("¿Desea detenerla? y/n");
					yesno = Leer.dato();
					if (yesno.equalsIgnoreCase("y")) {
						gd.update(buscarNombre, buscarId);
						if (gd.update(buscarNombre, buscarId) == 1 || gd.update(buscarNombre, buscarId) == 0) {
							System.out.println("Descarga detenida");
						} else {
							System.out.println("No se ha podido detener la descarga");
						}
					}

					break;
				case 2:
					System.out.println("Escriba el id");
					buscarId = Leer.dato();
					System.out.println(buscarId);
					gd.mostrarDescarga(buscarId, buscarNombre);
					System.out.println("¿Desea detenerla? y/n");
					yesno = Leer.dato();
					if (yesno.equalsIgnoreCase("y")) {
						if (gd.update(buscarNombre, buscarId) == 1 || gd.update(buscarNombre, buscarId) == 0) {
							System.out.println("Descarga detenida");
						} else {
							System.out.println("No se ha podido detener la descarga");
						}

					}

				default:
					break;

				}

				break;

			case 5:
				buscarId = "";
				buscarNombre = "";
				System.out.println("Pulse 1 para borrar por nombre");
				System.out.println("Pulse 2 para borrar por id");
				opcion2 = Leer.datoInt();
				if (opcion2 == 1) {
					System.out.println("Escriba el nombre");
					buscarNombre = Leer.dato();
				} else if (opcion2 == 2) {
					System.out.println("Escriba el id");
					buscarId = Leer.dato();
				}
				if (gd.delete(buscarNombre, buscarId) == 1 || gd.delete(buscarNombre, buscarId) == 0) {
					System.out.println("Archivo eliminado y descarga detenida correctamente.");
				} else {
					System.out.println("No se pudo encontrar el archivo para eliminar.");
				}
				break;

			case 0:
				System.out.println("Saliendo...");
				break;

			default:
				System.out.println("Número erroneo");
				break;
			}

		} while (opcion != 0);

	}

}
