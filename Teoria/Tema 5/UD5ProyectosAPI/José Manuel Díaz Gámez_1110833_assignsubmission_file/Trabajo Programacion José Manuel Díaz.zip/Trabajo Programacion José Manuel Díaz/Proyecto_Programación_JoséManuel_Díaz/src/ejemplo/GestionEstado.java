package ejemplo;

import ejemplo.Enum.EstadoPedido;

public class GestionEstado {

	// 1. compareTo()
    // Compara dos estados seg�n el orden en que est�n declarados
    public int compararEstados(EstadoPedido e1, EstadoPedido e2) {
        return e1.compareTo(e2);
    } 

    // 2. equals()
    // Comprueba si dos estados son iguales
    public boolean sonIguales(EstadoPedido e1, EstadoPedido e2) {
        return e1.equals(e2);
    }

    // 3. hashCode() 
    // Devuelve un c�digo �nico del estado (es bastante util en estructuras hash)
    public int obtenerHash(EstadoPedido e) {
        return e.hashCode();
    }

    // 4. name()
    // Devuelve el nombre EXACTO del enum
    public String obtenerNombre(EstadoPedido e) {
        return e.name();
    }

    // 5. ordinal()
    // Devuelve la posici�n del enum (la cual empieza en 0)
    public int obtenerPosicion(EstadoPedido e) {
        return e.ordinal();
    }

    // 6. toString()
    // Devuelve el nombre del enum (normalmente igual que name)
    public String convertirAString(EstadoPedido e) {
        return e.toString();
    }
 
    // 7. valueOf()
    // Convierte un texto en un enum
    public EstadoPedido convertirDesdeTexto(String texto) {
        return EstadoPedido.valueOf(texto);
    }

    // 8. clone()
    // Esta es la forma normal de usar el clone
    public EstadoPedido probarClone(EstadoPedido e) {
        return EstadoPedido.valueOf(e.name());
        //Otra manera de hacerlo seria simplemente devolviendo "e"
        // return e;
    }
    
    //Si intentamos clonar un enum, este dar� un error
    
    /*public void probarClone(EstadoPedido e) {
        try {
            Object copia = e.clone(); 
        } catch (CloneNotSupportedException ex) {
            System.out.println("No se puede clonar un enum.");
        }
     */

}
