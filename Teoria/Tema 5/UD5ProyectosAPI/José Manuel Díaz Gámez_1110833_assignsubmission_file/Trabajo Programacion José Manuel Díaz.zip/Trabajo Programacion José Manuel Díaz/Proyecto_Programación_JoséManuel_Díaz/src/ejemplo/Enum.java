package ejemplo;

public class Enum {
	
		/**
		 * Este es un tipo enum que define los posibles estados
		 * que puede tener un pedido en un sistema.
		 * 
		 * Los valores posibles son:
		 * PENDIENTE: El pedido ha sido creado pero a�n no ha sido procesado.
		 * ENVIADO: El pedido ha sido despachado y est� en camino.
		 * ENTREGADO: El pedido ha sido recibido por el cliente.
		 * CANCELADO: El pedido fue anulado antes de ser entregado.
		 * 
		 * Al ser un enum, estos valores son constantes y se comportan
		 * como objetos �nicos, lo que permite un uso m�s seguro y
		 * legible que usar simples enteros o cadenas.
		 */
	public enum EstadoPedido {

		PENDIENTE,
		ENVIADO,
		ENTREGADO,
		CANCELADO;
		}

}
