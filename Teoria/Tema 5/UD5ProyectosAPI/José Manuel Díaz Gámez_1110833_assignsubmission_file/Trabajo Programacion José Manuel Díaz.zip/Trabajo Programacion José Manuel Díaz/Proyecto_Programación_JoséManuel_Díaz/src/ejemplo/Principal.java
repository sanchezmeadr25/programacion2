package ejemplo;

import ejemplo.Enum.EstadoPedido;
import utilidades.Leer;

public class Principal {

	/* Enunciado
	 * 
	 * Realiza un programa con un men� interactivo para gestionar los estados 
	 * de un env�o usando un enum llamado EstadoPedido (PENDIENTE, ENVIADO, 
	 * ENTREGADO, CANCELADO).
	 * 
	 * Crea una clase que se llame GestionEstado donde usaras 
	 * m�todos para probar las utilidades de los enum. 
	 * 
	 * Deberas tener: 
	 * Un comparar orden (compareTo), comprobar igualdad (equals), obtener identificador (hashCode), 
	 * extraer nombre (name y toString) y ver posici�n (ordinal). 
	 * Tambi�n se incluir� una opci�n para intentar usar el m�todo clone() 
	 * (simul�ndolo o comentando el c�digo para demostrar por qu� Java proh�be clonar un enum).
	 * 
	 * El programa pedir� siempre al usuario que introduzca el nombre 
	 * del estado por teclado y usar� obligatoriamente el m�todo valueOf para 
	 * convertir ese texto en un objeto enum real antes de operar con �l.
	 * */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		GestionEstado gestion = new GestionEstado();
	    int opcion;

	    do {
	        System.out.println("\n--- MEN� ---");
	        System.out.println("Pulse [0] para salir del programa");
	        System.out.println("Pulse [1] para comparar estados");
	        System.out.println("Pulse [2] para comprobar si son iguales");
	        System.out.println("Pulse [3] para obtener hashCode");
	        System.out.println("Pulse [4] para obtener nombre (name)");
	        System.out.println("Pulse [5] para obtener posici�n (ordinal)");
	        System.out.println("Pulse [6] para convertir a String (toString)");
	        System.out.println("Pulse [7] para convertir texto a enum (valueOf)");
	        System.out.println("Pulse [8] para probar clone");
	        opcion=Leer.datoInt();    

	        switch (opcion) {
	        
	            case 0:
	                System.out.println("Saliendo del programa...");
	                break;
	                  
	            case 1: {
	                EstadoPedido e1 = EstadoPedido.PENDIENTE;
	                EstadoPedido e2 = EstadoPedido.ENVIADO;

	                System.out.println("compareTo: " + gestion.compararEstados(e1, e2));
	                break;
	            }

	            case 2: {
	                EstadoPedido e1 = EstadoPedido.ENTREGADO;
	                EstadoPedido e2 = EstadoPedido.ENTREGADO;

	                System.out.println("equals: " + gestion.sonIguales(e1, e2));
	                break;
	            }

	            case 3: {
	                EstadoPedido e = EstadoPedido.CANCELADO;

	                System.out.println("hashCode: " + gestion.obtenerHash(e));
	                break;
	            }

	            case 4: {
	                EstadoPedido e = EstadoPedido.PENDIENTE;

	                System.out.println("name: " + gestion.obtenerNombre(e));
	                break;
	            }

	            case 5: {
	                EstadoPedido e = EstadoPedido.ENVIADO;

	                System.out.println("ordinal: " + gestion.obtenerPosicion(e));
	                break;
	            }

	            case 6: {
	                EstadoPedido e = EstadoPedido.ENTREGADO;

	                System.out.println("toString: " + gestion.convertirAString(e));
	                break;
	            }

	            case 7: {
	                EstadoPedido e = gestion.convertirDesdeTexto("PENDIENTE");

	                System.out.println("valueOf: " + e);
	                break;
	            }

	            case 8: {
	                EstadoPedido e = EstadoPedido.CANCELADO;

	                gestion.probarClone(e);
	                break;
	            }

	            default:
	                System.out.println("No es valido");
	                break;
	          }

	    } while (opcion != 0);

	    System.out.println("Gracias por usar este programa :)");
	}

}
