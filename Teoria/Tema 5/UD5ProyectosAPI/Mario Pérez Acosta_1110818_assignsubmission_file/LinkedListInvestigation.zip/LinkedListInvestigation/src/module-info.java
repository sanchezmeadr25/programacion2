/**
 * 
 */
/**
 * 
 */
module LinkedListInvestigation {
}