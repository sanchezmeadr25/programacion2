package ejemplo;

import java.util.Objects;

public class Pregunta {
    private String texto;
    private String dificultad;

    public Pregunta(String texto, String dificultad) {
        this.texto = texto;
        this.dificultad = dificultad;
    }

    public String getTexto() {
        return texto;
    }

    public String getDificultad() {
        return dificultad;
    }

    // OBLIGATORIO: Para que Collections sepa encontrar secuencias exactas (subList)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pregunta pregunta = (Pregunta) o;
        return Objects.equals(texto, pregunta.texto);
    }

    @Override
    public String toString() {
        return "[" + dificultad + "] " + texto;
    }
}