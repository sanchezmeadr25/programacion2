package ejemplo;


import java.util.List;

import utilidades.Leer;

//

public class Principal  {
    public static void main(String[] args) {
    	
    	int opcion;
    	String dificultad;
        Gestor miJuego = new Gestor();
        
        // Añadimos preguntas
        miJuego.anadir(new Pregunta("¿Capital de Italia?", "Facil"));
        miJuego.anadir(new Pregunta("¿Fórmula del ozono?", "Dificil")); // Inicio combo
        miJuego.anadir(new Pregunta("¿Símbolo del Oro?", "Media"));     // Fin combo
        miJuego.anadir(new Pregunta("¿Cuánto es 2+2?", "Facil"));
        miJuego.anadir(new Pregunta("¿Fórmula del ozono?", "Dificil")); // Inicio combo repetido
        miJuego.anadir(new Pregunta("¿Símbolo del Oro?", "Media"));     // Fin combo repetido

        System.out.println("Bienvenido. Este programa simula un gestor para una serie de preguntas");
        
        do {
            System.out.println("Elije una de las siguientes opciones.");
            System.out.println("1. VER TODAS LAS PREGUNTAS");
            System.out.println("2. BUSCAR RONDA DE CIENCIAS (indexOfSubList)");
            System.out.println("3. LISTA EN REVERSA (Reverse)");
            System.out.println("4. BARAJAR PREGUNTAS (Shuffle)");
            System.out.println("5. BORRAR PREGUNTAS FÁCILES (removeIf)");
            System.out.println("Introduce la opcion elegida: ");
            opcion = Leer.datoInt();
        	switch (opcion) {
        	case 1:
        	// Imprimimos usando programación funcional (forEach)
            miJuego.verPreguntas().forEach(p -> System.out.println(p));
            System.out.println();
            break;
            
        	case 2:
            // Creamos la secuencia exacta que queremos buscar
            List<Pregunta> rondaCiencias = List.of(
                new Pregunta("¿Fórmula del ozono?", "Dificil"), 
                new Pregunta("¿Símbolo del Oro?", "Media")
            );
            miJuego.mostrarRonda(rondaCiencias);
            System.out.println();
            break;
            
        	case 3:
            miJuego.invertirOrden();
            miJuego.verPreguntas().forEach(System.out::println);
            System.out.println();
            break;
            
        	case 4:
            miJuego.barajar();
            miJuego.verPreguntas().forEach(System.out::println);
            System.out.println();
            break;
            
        	case 5:
        	System.out.println("Introduce la dificultad de las preguntas que quieres borrar");
        	dificultad= Leer.dato();
            miJuego.borrarPorDificultad(dificultad);
            miJuego.verPreguntas().forEach(System.out::println);
            System.out.println();
            break;
        	}
        	 
        	
        } while (opcion !=0);
       
    }
}