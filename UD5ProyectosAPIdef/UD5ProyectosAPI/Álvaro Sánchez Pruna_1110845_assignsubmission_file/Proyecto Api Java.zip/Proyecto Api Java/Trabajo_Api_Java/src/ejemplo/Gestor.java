package ejemplo;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Gestor {
    private List<Pregunta> banco;

    public Gestor() {
        // 1. CHECKED: Evita que metamos algo que no es
        banco = Collections.checkedList(new ArrayList<>(), Pregunta.class);
    }

    public void anadir(Pregunta p) {
        banco.add(p);
    }

    // 2 y 3. EMPTY y UNMODIFIABLE
    public List<Pregunta> verPreguntas() {
        if (banco.isEmpty()) {
            return Collections.emptyList(); // Si no hay preguntas, devolvemos lista vacía (no null)
        }
        return Collections.unmodifiableList(banco); // Hace que solo se pueda leer para que no se modifique nada
    }

    // 4. REVERSE
    public void invertirOrden() {
        Collections.reverse(banco);
    }

    // 5. SHUFFLE
    public void barajar() {
        Collections.shuffle(banco);
    }

    // 6. BÚSQUEDA DE SUBLISTAS (Secuencias)
    public void mostrarRonda(List<Pregunta> rondaBuscada) {
        int primeraVez = Collections.indexOfSubList(banco, rondaBuscada);
        int ultimaVez = Collections.lastIndexOfSubList(banco, rondaBuscada);

        if (primeraVez != -1) {
            System.out.println("Esa secuencia de preguntas aparece por primera vez en la posición: " + primeraVez);
            System.out.println("Y por última vez en la posición: " + ultimaVez);
        } else {
            System.out.println("No se ha encontrado esa secuencia exacta en el banco.");
        }       
        
    }

    // 7. PROGRAMACIÓN FUNCIONAL (Lambdas)
    public void borrarPorDificultad(String dificultad) {
        // Le decimos QUÉ borrar usando una función Lambda, sin usar bucles for
        banco.removeIf(p -> p.getDificultad().equalsIgnoreCase(dificultad));
    }
}
