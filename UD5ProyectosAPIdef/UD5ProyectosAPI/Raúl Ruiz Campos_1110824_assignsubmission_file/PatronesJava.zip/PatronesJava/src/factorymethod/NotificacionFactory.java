package factorymethod;

/**
 * PASO 3 - FACTORY METHOD
 * 
 * Interfaz base para las fábricas.
 * Define el método abstracto "crearNotificacion" que CADA FÁBRICA implementará
 * a su manera.
 * 
 * Clave del patrón: hay UNA fábrica por tipo de producto.
 * Si mañana añadimos WhatsApp, solo creamos una nueva clase fábrica,
 * sin tocar el código existente (principio Abierto/Cerrado ).
 */
public interface NotificacionFactory {

    /**
     * El "factory method": cada subclase decide qué producto concreto crea.
     * @param destinatario a quién va dirigida la notificación
     * @return una instancia de Notificacion (puede ser Email, SMS, Push...)
     */
    Notificacion crearNotificacion(String destinatario);
}


/**
 * Fábrica concreta que crea NotificacionEmail.
 * El cliente puede usar esta fábrica sin saber nada de NotificacionEmail.
 */
class EmailFactory implements NotificacionFactory {

    @Override
    public Notificacion crearNotificacion(String destinatario) {
        // PASO 5: Aquí creamos y devolvemos el producto concreto
        return new NotificacionEmail(destinatario);
    }
}

/**
 * Fábrica concreta que crea NotificacionSMS.
 */
class SMSFactory implements NotificacionFactory {

    @Override
    public Notificacion crearNotificacion(String destinatario) {
        return new NotificacionSMS(destinatario);
    }
}

/**
 * Fábrica concreta que crea NotificacionPush.
 */
class PushFactory implements NotificacionFactory {

    @Override
    public Notificacion crearNotificacion(String destinatario) {
        return new NotificacionPush(destinatario);
    }
}
