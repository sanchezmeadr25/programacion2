package factorymethod;

/**
 * PASO 6 - FACTORY METHOD
 * 
 * Clase principal (cliente) que usa el patrón Factory Method.
 * 
 * Diferencia clave respecto al Simple Factory:
 *   - Simple Factory: una sola clase fábrica con un switch/if.
 *   - Factory Method: cada tipo de producto tiene SU PROPIA fábrica.
 * 
 * El cliente decide qué fábrica usar, pero no conoce los productos concretos.
 * Si añadimos "WhatsAppFactory", el cliente puede usarla sin cambiar nada más.
 * 
 * EJECUTA ESTA CLASE para ver el patrón en acción.
 */
public class MainFactoryMethod {

    public static void main(String[] args) {

        System.out.println("=== DEMOSTRACIÓN: FACTORY METHOD ===\n");

        // El cliente elige la fábrica según su necesidad
        // La variable es de tipo NotificacionFactory (la interfaz), no la clase concreta
        NotificacionFactory fabrica;

        // --- Usar la fábrica de Email ---
        System.out.println("--- Usando EmailFactory ---");
        fabrica = new EmailFactory();
        Notificacion n1 = fabrica.crearNotificacion("usuario@correo.com");
        n1.enviar("Tu pedido ha sido confirmado.");

        // --- Usar la fábrica de SMS ---
        System.out.println("\n--- Usando SMSFactory ---");
        fabrica = new SMSFactory();
        Notificacion n2 = fabrica.crearNotificacion("+34 612 345 678");
        n2.enviar("Código de verificación: 48291. Caduca en 5 minutos.");

        // --- Usar la fábrica de Push ---
        System.out.println("\n--- Usando PushFactory ---");
        fabrica = new PushFactory();
        Notificacion n3 = fabrica.crearNotificacion("dispositivo-abc-123");
        n3.enviar("¡Tienes un nuevo mensaje!");

        // --- Demostración polimórfica ---
        // La misma función puede recibir cualquier fábrica sin modificarse
        System.out.println("\n--- Envío polimórfico con distintas fábricas ---");
        NotificacionFactory[] fabricas = {new EmailFactory(), new SMSFactory(), new PushFactory()};
        String[] destinos = {"admin@web.com", "+34 600 111 222", "device-xyz"};

        for (int i = 0; i < fabricas.length; i++) {
            enviarNotificacion(fabricas[i], destinos[i], "Bienvenido al sistema");
        }

        System.out.println("\n=== FIN FACTORY METHOD ===");
    }

    /**
     * Método auxiliar que demuestra cómo el cliente trabaja solo con interfaces.
     * No importa qué fábrica recibe, el comportamiento es correcto.
     * 
     * @param factory    cualquier implementación de NotificacionFactory
     * @param destino    a quién enviar
     * @param mensaje    qué enviar
     */
    static void enviarNotificacion(NotificacionFactory factory, String destino, String mensaje) {
        Notificacion notif = factory.crearNotificacion(destino);
        notif.enviar(mensaje);
    }
}
