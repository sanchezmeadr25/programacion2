package factorymethod;

/**
 * PASO 1 - FACTORY METHOD
 * 
 * Clase base (o interfaz) que representa el "producto" que las fábricas crearán.
 * 
 * A diferencia del Simple Factory, aquí cada fábrica será una clase propia.
 * Esta clase abstracta define qué comportamiento tendrán todos los productos.
 * 
 * Ejemplo: Diferentes tipos de notificaciones (Email, SMS, Push).
 */
public abstract class Notificacion {

    // Atributo común a todas las notificaciones
    protected String destinatario;

    public Notificacion(String destinatario) {
        this.destinatario = destinatario;
    }

    /**
     * Método abstracto: cada subclase definirá cómo envía su notificación.
     */
    public abstract void enviar(String mensaje);

    /**
     * Método concreto compartido por todas las notificaciones.
     */
    public String getDestinatario() {
        return destinatario;
    }
}
