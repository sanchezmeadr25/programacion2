package factorymethod;

/**
 * PASO 2 - FACTORY METHOD
 * 
 * Clases hija que extienden la clase base Notificacion.
 * Cada una implementa su propia lógica de envío.
 * Estas son los "productos concretos" que cada fábrica creará.
 */

// --- Producto concreto: NotificacionEmail ---
class NotificacionEmail extends Notificacion {

    public NotificacionEmail(String destinatario) {
        super(destinatario);
    }

    @Override
    public void enviar(String mensaje) {
        System.out.println("[EMAIL] Para: " + destinatario
                + " | Mensaje: " + mensaje);
    }
}

// --- Producto concreto: NotificacionSMS ---
class NotificacionSMS extends Notificacion {

    public NotificacionSMS(String destinatario) {
        super(destinatario);
    }

    @Override
    public void enviar(String mensaje) {
        String mensajeCorto = mensaje.length() > 30 ? mensaje.substring(0, 30) + "..." : mensaje;
        System.out.println("[SMS] Para: " + destinatario
                + " | Mensaje: " + mensajeCorto);
    }
}

// --- Producto concreto: NotificacionPush ---
class NotificacionPush extends Notificacion {

    public NotificacionPush(String destinatario) {
        super(destinatario);
    }

    @Override
    public void enviar(String mensaje) {
        System.out.println("[PUSH] Dispositivo: " + destinatario
                + " | Alerta: " + mensaje);
    }
}
