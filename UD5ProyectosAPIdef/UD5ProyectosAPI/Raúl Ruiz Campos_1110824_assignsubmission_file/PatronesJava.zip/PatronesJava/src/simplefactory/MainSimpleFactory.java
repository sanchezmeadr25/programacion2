package simplefactory;

/**
 * PASO 5 - SIMPLE FACTORY
 * 
 * Clase principal (cliente) que usa la fábrica.
 * 
 * El cliente NO sabe si está recibiendo un Coche, Moto o Camion.
 * Solo sabe que recibe algo de tipo Vehiculo y llama a sus métodos.
 * 
 * Esto se llama "bajo acoplamiento": el cliente depende de la interfaz,
 * no de las clases concretas.
 * 
 * EJECUTA ESTA CLASE para ver el patrón en acción.
 */
public class MainSimpleFactory {

    public static void main(String[] args) {

        System.out.println("=== DEMOSTRACIÓN: SIMPLE FACTORY ===\n");

        // Nota: el tipo de la variable es Vehiculo (la interfaz), no Coche/Moto/Camion
        Vehiculo v1 = VehiculoFactory.crearVehiculo("coche");
        Vehiculo v2 = VehiculoFactory.crearVehiculo("moto");
        Vehiculo v3 = VehiculoFactory.crearVehiculo("camion");

        // El cliente trabaja con la interfaz base
        v1.describir();
        v2.describir();
        v3.describir();

        System.out.println("\n--- Tipos obtenidos ---");
        System.out.println("v1 es: " + v1.getTipo());
        System.out.println("v2 es: " + v2.getTipo());
        System.out.println("v3 es: " + v3.getTipo());

        System.out.println("\n--- Uso en un bucle (sin saber el tipo concreto) ---");
        String[] tiposSolicitados = {"coche", "moto", "camion", "coche"};

        for (String tipo : tiposSolicitados) {
            Vehiculo v = VehiculoFactory.crearVehiculo(tipo);
            System.out.print("[" + tipo + "] -> ");
            v.describir();
        }

        System.out.println("\n--- Prueba con tipo desconocido (lanza excepción) ---");
        try {
            Vehiculo vDesconocido = VehiculoFactory.crearVehiculo("avion");
        } catch (IllegalArgumentException e) {
            System.out.println("ERROR capturado: " + e.getMessage());
        }

        System.out.println("\n=== FIN SIMPLE FACTORY ===");
    }
}
