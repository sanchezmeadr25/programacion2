package simplefactory;

/**
 * PASO 1 - SIMPLE FACTORY
 * 
 * Interfaz base (contrato común) que todos los objetos creados por la fábrica deben cumplir.
 * El cliente solo conoce esta interfaz, no las clases concretas.
 * 
 * En este ejemplo, la fábrica creará diferentes tipos de vehículos.
 */
public interface Vehiculo {

    /**
     * Método que todos los vehículos deben implementar.
     * Define el "contrato" que la fábrica garantiza al cliente.
     */
    void describir();

    String getTipo();
}
