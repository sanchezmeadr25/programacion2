package simplefactory;

/**
 * Clases concretas que implementan la interfaz Vehiculo.
 * Cada una tiene su propio comportamiento, pero cumple el contrato de la interfaz.
 * 
 * Se agrupan en un mismo archivo para mantener el proyecto ordenado.
 */

// --- Clase concreta: Coche ---
class Coche implements Vehiculo {

    @Override
    public void describir() {
        System.out.println("Soy un COCHE. Tengo 4 ruedas y voy por carretera.");
    }

    @Override
    public String getTipo() {
        return "Coche";
    }
}

// --- Clase concreta: Moto ---
class Moto implements Vehiculo {

    @Override
    public void describir() {
        System.out.println("Soy una MOTO. Tengo 2 ruedas y soy muy ágil.");
    }

    @Override
    public String getTipo() {
        return "Moto";
    }
}

// --- Clase concreta: Camion ---
class Camion implements Vehiculo {

    @Override
    public void describir() {
        System.out.println("Soy un CAMIÓN. Tengo muchas ruedas y transporto grandes cargas.");
    }

    @Override
    public String getTipo() {
        return "Camion";
    }
}
