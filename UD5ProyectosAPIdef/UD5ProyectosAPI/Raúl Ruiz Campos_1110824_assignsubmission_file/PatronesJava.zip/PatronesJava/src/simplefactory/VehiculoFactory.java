package simplefactory;

/**
 * La clase fábrica: contiene UN ÚNICO método que decide qué objeto crear
 * según el parámetro recibido.
 * 
 * VENTAJA: El cliente nunca usa "new Coche()" ni "new Moto()" directamente.
 *          Solo llama a esta fábrica y trabaja con la interfaz Vehiculo.
 * 
 * DESVENTAJA: Si añadimos un nuevo vehículo, tenemos que modificar este método
 *             (viola el principio Abierto/Cerrado).
 */
public class VehiculoFactory {

    /**
     * Método estático de creación.
     * Recibe un String con el tipo de vehículo y devuelve la instancia correcta.
     * 
     * @param tipo  "coche", "moto" o "camion"
     * @return una instancia que cumple la interfaz Vehiculo
     */
    public static Vehiculo crearVehiculo(String tipo) {

        // Con un switch decidimos qué clase concreta instanciar
        switch (tipo.toLowerCase()) {
            case "coche":
                return new Coche();   // Instanciamos la clase concreta aquí dentro
            case "moto":
                return new Moto();
            case "camion":
                return new Camion();
            default:
                // Si el tipo no existe, lanzamos una excepción clara
                throw new IllegalArgumentException("Tipo de vehículo desconocido: " + tipo);
        }
    }
}
