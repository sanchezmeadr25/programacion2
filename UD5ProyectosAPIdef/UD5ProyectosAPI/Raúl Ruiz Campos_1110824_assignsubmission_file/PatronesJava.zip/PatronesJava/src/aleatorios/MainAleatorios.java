package aleatorios;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.security.SecureRandom;

/**
 * GENERACIÓN DE ALEATORIOS EN JAVA
 * 
 * Este paquete explica las 4 formas principales de generar valores aleatorios en Java:
 *   1. Math.random()
 *   2. Random (java.util.Random)
 *   3. ThreadLocalRandom
 *   4. SecureRandom
 * 
 * EJECUTA ESTA CLASE para ver todos los ejemplos.
 */
public class MainAleatorios {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("============================================");
        System.out.println("  GENERACIÓN DE ALEATORIOS EN JAVA");
        System.out.println("============================================\n");

        demoMathRandom();
        demoRandom();
        demoThreadLocalRandom();
        demoSecureRandom();
        demoComparativaRangos();
    }


    // ============================================================
    // 1. Math.random()
    // ============================================================

    /**
     * MATH.RANDOM()
     * 
     * - No necesita importar nada (está en java.lang)
     * - Devuelve siempre un double entre 0.0 (incluido) y 1.0 (excluido)
     * - Es un método estático, no creas instancia
     * - No puedes fijar la semilla
     * - Ideal para usos simples y rápidos
     */
    static void demoMathRandom() {
        System.out.println("--- 1. Math.random() ---\n");


        double valorBase = Math.random();
        System.out.println("Valor base (0.0 - 1.0): " + valorBase);

        int max = 10;
        int enteroRango = (int) (Math.random() * max);
        System.out.println("Entero en rango [0, " + max + "): " + enteroRango);


        int min = 5;
        int enteroPersonalizado = min + (int) (Math.random() * (max - min));
        System.out.println("Entero en rango [" + min + ", " + max + "): " + enteroPersonalizado);


        System.out.println();
    }


    // ============================================================
    // 2. Random (java.util.Random)
    // ============================================================

    /**
     * RANDOM
     * 
     * - Hay que importar java.util.Random
     * - Se crea una instancia con "new Random()"
     * - Muy versátil: genera int, double, boolean, long, float...
     * - Permite fijar una semilla para reproducir la misma secuencia
     * - No es seguro para criptografía
     */
    static void demoRandom() {
        System.out.println("--- 2. Random (java.util.Random) ---\n");


        Random random = new Random();


        int cualquierEntero = random.nextInt();
        System.out.println("nextInt() sin límite: " + cualquierEntero);


        int entre0y100 = random.nextInt(100);
        System.out.println("nextInt(100) -> [0, 100): " + entre0y100);


        double decimales = random.nextDouble();
        System.out.println("nextDouble() -> [0.0, 1.0): " + decimales);


        boolean boolAleatorio = random.nextBoolean();
        System.out.println("nextBoolean(): " + boolAleatorio);


        long numeroLargo = random.nextLong();
        System.out.println("nextLong(): " + numeroLargo);

        System.out.println("\n  [Con semilla fija = 42, siempre misma secuencia]");
        Random randomConSemilla = new Random(42);
        for (int i = 0; i < 5; i++) {
            System.out.print(randomConSemilla.nextInt(100) + " ");
        }
        System.out.println("\n  (Ejecuta varias veces: los números no cambian)\n");
    }


    // ============================================================
    // 3. ThreadLocalRandom
    // ============================================================

    /**
     * THREADLOCALRANDOM
     * 
     * - Importar java.util.concurrent.ThreadLocalRandom
     * - NO se crea instancia con "new": se usa ThreadLocalRandom.current()
     * - Diseñado para aplicaciones con múltiples hilos (multithreading)
     * - Mejor rendimiento que Random en entornos concurrentes
     * - Sintaxis más limpia para rangos
     * - No permite fijar semilla manualmente
     */
    static void demoThreadLocalRandom() throws InterruptedException {
        System.out.println("--- 3. ThreadLocalRandom ---\n");



        int entero = ThreadLocalRandom.current().nextInt(1, 50); 
        System.out.println("nextInt(1, 50) -> [1, 50): " + entero);

        double decimal = ThreadLocalRandom.current().nextDouble(0.5, 1.5);
        System.out.println("nextDouble(0.5, 1.5): " + decimal);

        long largo = ThreadLocalRandom.current().nextLong(100, 200); 
        System.out.println("nextLong(100, 200): " + largo);

        boolean bool = ThreadLocalRandom.current().nextBoolean();
        System.out.println("nextBoolean(): " + bool);


        System.out.println("\n  [Generando aleatorios desde 3 hilos en paralelo]");

        Runnable tarea = () -> {
            int valor = ThreadLocalRandom.current().nextInt(1000);
            System.out.println("  Hilo " + Thread.currentThread().getName() + " generó: " + valor);
        };

        Thread hilo1 = new Thread(tarea, "Hilo-A");
        Thread hilo2 = new Thread(tarea, "Hilo-B");
        Thread hilo3 = new Thread(tarea, "Hilo-C");

        hilo1.start(); hilo2.start(); hilo3.start();
        hilo1.join();  hilo2.join();  hilo3.join();

        System.out.println();
    }


    // ============================================================
    // 4. SecureRandom
    // ============================================================

    /**
     * SECURERANDOM
     * 
     * - Importar java.security.SecureRandom
     * - Se crea instancia con "new SecureRandom()"
     * - Criptográficamente seguro: impredecible incluso para atacantes
     * - Más lento que Random, pero necesario para contraseñas, tokens, claves
     * - Ideal cuando los valores NO deben ser adivinables
     */
    static void demoSecureRandom() {
        System.out.println("--- 4. SecureRandom ---\n");


        SecureRandom secureRandom = new SecureRandom();


        int enteroSeguro = secureRandom.nextInt(1000);
        System.out.println("nextInt(1000) seguro: " + enteroSeguro);

        double decimalSeguro = secureRandom.nextDouble();
        System.out.println("nextDouble() seguro: " + decimalSeguro);


        byte[] token = new byte[16]; // 16 bytes = 128 bits
        secureRandom.nextBytes(token);

    
        StringBuilder hex = new StringBuilder();
        for (byte b : token) {
            hex.append(String.format("%02x", b));
        }
        System.out.println("Token de 16 bytes (hex): " + hex.toString());


        int pin = 100000 + secureRandom.nextInt(900000); // [100000, 999999]
        System.out.println("PIN de 6 dígitos: " + pin);

        System.out.println();
    }


    // ============================================================
    // 5. Comparativa de rangos
    // ============================================================

    /**
     * COMPARATIVA: Cómo generar el mismo rango con cada método.
     * Aquí se puede ver claramente la diferencia de sintaxis.
     */
    static void demoComparativaRangos() {
        System.out.println("--- 5. Comparativa: Entero en rango [10, 20) con cada método ---\n");

        int min = 10, max = 20;

        // Math.random()
        int r1 = min + (int)(Math.random() * (max - min));
        System.out.println("Math.random():        " + r1);

        // Random
        Random random = new Random();
        int r2 = random.nextInt(max - min) + min;
        System.out.println("Random:               " + r2);

        // ThreadLocalRandom (sintaxis más limpia)
        int r3 = ThreadLocalRandom.current().nextInt(min, max);
        System.out.println("ThreadLocalRandom:    " + r3);

        // SecureRandom
        SecureRandom sr = new SecureRandom();
        int r4 = sr.nextInt(max - min) + min;
        System.out.println("SecureRandom:         " + r4);

        System.out.println("\n¡Todos generan en el mismo rango [10, 20), cada uno con distinto uso!");
        System.out.println("\n============================================");
        System.out.println("  FIN DE GENERACIÓN DE ALEATORIOS");
        System.out.println("============================================");
    }
}
