package trabajo;


import utilidades.Leer;

/*
 * ENUNCIADO:
 * Sistema de gestión para una campaña electoral.
 * Permite guardar candidatos políticos y realizar operaciones de análisis 
 * de datos (conteo de votos, filtrado por partidos, ránkings y estadísticas) 
 * utilizando operaciones intermedias y terminales
 */
public class Principal {

    public static void main(String[] args) {
        GestorCampana gestor = new GestorCampana();
        int opcion = 0;

        gestor.anadirPolitico(new Politico("Laura", "Partido A", 35, 15000));
        gestor.anadirPolitico(new Politico("Carlos", "Partido B", 50, 20000));
        gestor.anadirPolitico(new Politico("Elena", "Partido A", 42, 18000));
        gestor.anadirPolitico(new Politico("Mario", "Partido C", 28, 5000));
        gestor.anadirPolitico(new Politico("Ana", "Partido B", 60, 25000));
        gestor.anadirPolitico(new Politico("Luis", "Partido C", 30, 0));
        
        do {
            System.out.println("\nMENÚ");
            System.out.println("1. Mostrar candidatos del 'Partido A' (filter + forEach)");
            System.out.println("2. Ver partidos políticos únicos (distinct + collect)");
            System.out.println("3. Contar candidatos menores de 40 años (count)");
            System.out.println("4. Comprobar requisitos legales (anyMatch / allMatch)");
            System.out.println("5. Ver candidato más y menos votado (max / min)");
            System.out.println("6. Calcular total de votos emitidos (reduce)");
            System.out.println("7. Ver TOP 3 candidatos más votados (limit + collect joining)");
            System.out.println("8. Lista alfabética saltando el primero (sorted + skip)");
            System.out.println("9. Salir");
            System.out.print("Elige una opción: ");
            
            opcion = Leer.datoInt();

            switch (opcion) {
                case 1:
                    gestor.mostrarPoliticosPorPartido("Partido A");
                    break;
                case 2:
                    System.out.println("Partidos: " + gestor.obtenerPartidosUnicos());
                    break;
                case 3:
                    System.out.println("Candidatos jóvenes: " + gestor.contarPoliticosJovenes());
                    break;
                case 4:
                    gestor.comprobarRequisitosLegales();
                    break;
                case 5:
                    gestor.mostrarExtremosVotacion();
                    break;
                case 6:
                    System.out.println("Total de votos: " + gestor.calcularTotalVotos());
                    break;
                case 7:
                    System.out.println("TOP 3: " + gestor.obtenerTop3Nombres());
                    break;
                case 8:
                    gestor.mostrarNombresOrdenadosSaltandoElPrimero();
                    break;
                case 9:
                    System.out.println("Saliendo.");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 9);

    }
}