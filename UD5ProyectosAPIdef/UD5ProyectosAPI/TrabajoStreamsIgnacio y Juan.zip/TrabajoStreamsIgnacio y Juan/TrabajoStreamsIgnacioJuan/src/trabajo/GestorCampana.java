package trabajo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class GestorCampana {
    
	private List<Politico> politicos;

    public GestorCampana() {
        this.politicos = new ArrayList<>();
    }

    public void anadirPolitico(Politico p) {
        politicos.add(p);
    }

    // filter y forEach
    public void mostrarPoliticosPorPartido(String partido) {
        System.out.println("Políticos del partido: " + partido);
        politicos.stream()
                 .filter(p -> p.getPartido().equalsIgnoreCase(partido)) // INTERMEDIA
                 .forEach(p -> System.out.println(p));                  // TERMINAL
    }

    // map, distinct y collect
    public List<String> obtenerPartidosUnicos() {
        return politicos.stream()
                        .map(Politico::getPartido)       // INTERMEDIA: Extrae solamente el nombre del partido
                        .distinct()                      // INTERMEDIA: Elimina partidos repetidos
                        .collect(Collectors.toList());   // TERMINAL: Lo guarda en un nuevo List
    }

    // filter y count
    public long contarPoliticosJovenes() {
        return politicos.stream()
                        .filter(p -> p.getEdad() < 40) // INTERMEDIA
                        .count();                      // TERMINAL: Cuenta los que pasan el filtro
    }

    // anyMatch y allMatch
    public void comprobarRequisitosLegales() {
        boolean todosMayoresDeEdad = politicos.stream().allMatch(p -> p.getEdad() >= 18); // TERMINAL
        boolean hayAlguienSinVotos = politicos.stream().anyMatch(p -> p.getVotos() == 0); // TERMINAL
        
        System.out.println("¿Todos son mayores de edad? " + todosMayoresDeEdad);
        System.out.println("¿Hay algún político con 0 votos? " + hayAlguienSinVotos);
    }

    // max y min (con Comparator)
    public void mostrarExtremosVotacion() {
        Optional<Politico> masVotado = politicos.stream()
                .max(Comparator.comparing(Politico::getVotos)); // TERMINAL
        
        Optional<Politico> menosVotado = politicos.stream()
                .min(Comparator.comparing(Politico::getVotos)); // TERMINAL

        masVotado.ifPresent(p -> System.out.println("Más votado: " + p.getNombre()));
        menosVotado.ifPresent(p -> System.out.println("Menos votado: " + p.getNombre()));
    }

    // map y reduce
    public int calcularTotalVotos() {
        return politicos.stream()
                        .map(Politico::getVotos)     // INTERMEDIA: Me quedo solo con los votos
                        .reduce(0, (a, b) -> a + b); // TERMINAL: Suma todos los votos partiendo de 0
    }

    // 7. sorted(comparator), limit, map y collect(joining)
    public String obtenerTop3Nombres() {
        return politicos.stream()
                        .sorted(Comparator.comparing(Politico::getVotos).reversed()) // INTERMEDIA: Ordena de más a menos votos
                        .limit(3)                                                    // INTERMEDIA: Se queda con los 3 primeros
                        .map(Politico::getNombre)                                    // INTERMEDIA: Extrae los nombres
                        .collect(Collectors.joining(", "));            // TERMINAL: Los une con comas
    }

    // 8. sorted, skip y forEach
    public void mostrarNombresOrdenadosSaltandoElPrimero() {
        System.out.println("Lista alfabética (sin el primero)");
        politicos.stream()
                 .map(Politico::getNombre)
                 .sorted()   // INTERMEDIA: Orden alfabético natural
                 .skip(1)    // INTERMEDIA: Se salta el primer elemento
                 .forEach(nombre -> System.out.println(nombre)); // TERMINAL
    }


    
    
}