package trabajo;
public class Politico {
    private String nombre;
    private String partido;
    private int edad;
    private int votos;
	
    public Politico(String nombre, String partido, int edad, int votos) {
		super();
		this.nombre = nombre;
		this.partido = partido;
		this.edad = edad;
		this.votos = votos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPartido() {
		return partido;
	}

	public void setPartido(String partido) {
		this.partido = partido;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public int getVotos() {
		return votos;
	}

	public void setVotos(int votos) {
		this.votos = votos;
	}

	@Override
	public String toString() {
		return "Politico [nombre=" + nombre + ", partido=" + partido + ", edad=" + edad + ", votos=" + votos + "]";
	}

    

}