package ejemplo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double media;
		
		
		/*
	     * ENUNCIADO:
	     * Crear un sistema de gestión bancaria que permita administrar objetos "Cuenta".
	     * Se debe implementar un CRUD completo, búsqueda por ID y cálculo de saldo medio.
	     * Además, el sistema debe permitir la ordenación de cuentas por capital mediante
	     * comparadores externos y cumplir con el uso de métodos default/private en interfaces.
	     */
		
		List<Cuenta> listaCuentas = new ArrayList <> ();
		GestionCuentas gc = new GestionCuentas(listaCuentas);
		
		gc.agregarCuenta(new Cuenta(1, "Ángel", "García", 1500.50));
        gc.agregarCuenta(new Cuenta(2, "María", "López", 3200.00));
        gc.agregarCuenta(new Cuenta(3, "Pepe", "Pérez", 850.25));

        System.out.println("\nLISTA INICIAL");
        gc.mostrarCuentas();

        // 2. Probar el método findById para buscar la cuenta de id 2
        System.out.println("\nBuscando ID 2");
        gc.abrirCuenta();
        System.out.println(gc.findById(2));

        // 3. Calculas la media de todas las cuentas
        media = gc.calcularMediaTodas();
        System.out.printf("\nEl saldo medio de todas las cuentas es: %.2f€", media);

        // 4. Ordenar de mayot a menor según el dinero de las cuentas
        System.out.println("\nOrdenar Cuentas (Mayor a Menor)");
        gc.OrdenarDeMayoraMenor();
        gc.mostrarCuentas();

        // 5. Borrar la cuenta de ID 3 y actualizar la suma de dinero de la cuenta de ID 1
        System.out.println("\nBorrando cuenta ID 3 y actualizando ID 1...");
        gc.eliminarCuenta(3);
        gc.cambiarDinero(1,2000.00);

        System.out.println("--- ESTADO FINAL ---");
        gc.mostrarCuentas();
		

	}

}
