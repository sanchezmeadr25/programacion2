package ejemplo;

import java.util.Comparator;


public class ComparaPorDinero implements Comparator<Cuenta>{

	@Override
	public int compare(Cuenta c1, Cuenta c2) {
		return Double.compare(c2.getDinero(),c1.getDinero());
	}

}
