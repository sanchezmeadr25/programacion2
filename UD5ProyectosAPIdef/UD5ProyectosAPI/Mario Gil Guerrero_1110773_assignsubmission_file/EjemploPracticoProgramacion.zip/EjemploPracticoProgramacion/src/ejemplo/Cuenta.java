package ejemplo;

public class Cuenta extends ComparaPorDinero{
    private int id;
    private String nombre;
    private String apellidos;
    private double dinero;
    
	public Cuenta(int id, String nombre, String apellidos, double dinero) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.dinero = dinero;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public double getDinero() {
		return dinero;
	}

	public void setDinero(double dinero) {
		this.dinero = dinero;
	}

	@Override
	public String toString() {
		return "Cuenta [id=" + id + ", nombre=" + nombre + ", apellidos=" + apellidos + ", dinero=" + dinero + "]";
	}
    
    
    
    
    
    
}