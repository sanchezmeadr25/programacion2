package ejemplo;

public interface Banca {

	
	default void abrirCuenta() {
		confirmarCuenta();
		System.out.println("Iniciando datos sobre la cuenta...");
		
		
        
    }

    // Método private: Solo puede ser usado dentro de esta interfaz (Java 9+)
    private void confirmarCuenta() {
        	
    System.out.println("El id que ha insertado es correcto, accediendo a la cuenta...");

        
    }

}
