package ejemplo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GestionCuentas implements Banca {
	
	
    private List<Cuenta> listaCuentas = new ArrayList <> ();

	public GestionCuentas(List<Cuenta> listaCuentas) {
		super();
		this.listaCuentas = listaCuentas;
	}
	
	public void agregarCuenta(Cuenta c) {
        listaCuentas.add(c);
    }

    public List <Cuenta> mostrarCuentas() {
    	for (Cuenta c : listaCuentas) {
            System.out.println(c);
    	}return null;
    }
    
    public Cuenta findById(int id) {
        for (Cuenta c : listaCuentas) {
            if (c.getId() == id) 
            	return c;
        }
        return null;
    }

    public void cambiarDinero(int id, double nuevoDinero) {
        Cuenta c = findById(id);
        if (c != null) 
        	c.setDinero(nuevoDinero);
    }

    public void OrdenarDeMayoraMenor() {
    	Collections.sort(listaCuentas,new ComparaPorDinero());
    }
    public void eliminarCuenta(int id) {
        listaCuentas.remove(findById(id));
    }

    public double calcularMediaTodas() {
    	double sumaTotal = 0.0;
        if (listaCuentas.isEmpty()) 
        	return -1;  
        for (Cuenta c : listaCuentas) {
            sumaTotal += c.getDinero();
        }
        return sumaTotal / listaCuentas.size();
    }
}