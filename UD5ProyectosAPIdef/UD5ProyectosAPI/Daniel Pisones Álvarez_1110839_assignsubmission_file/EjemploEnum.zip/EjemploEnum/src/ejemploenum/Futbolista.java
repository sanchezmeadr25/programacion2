package ejemploenum;

public class Futbolista {
	private int dorsal;
	private String nombre;
	private Equipo equipo;

	public Futbolista(String nombre, int dorsal, Equipo equipo) {
		this.dorsal = dorsal;
		this.nombre = nombre;
		this.equipo = equipo;
	}

	public int getDorsal() {
		return dorsal;
	}

	public void setDorsal(int dorsal) {
		this.dorsal = dorsal;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Equipo getEquipo() {
		return equipo;
	}

	public void setEquipo(Equipo equipo) {
		this.equipo = equipo;
	}

	@Override
	public String toString() {
		return "Futbolista [dorsal=" + dorsal + ", nombre=" + nombre + ", equipo=" + equipo + "]";
	}

}