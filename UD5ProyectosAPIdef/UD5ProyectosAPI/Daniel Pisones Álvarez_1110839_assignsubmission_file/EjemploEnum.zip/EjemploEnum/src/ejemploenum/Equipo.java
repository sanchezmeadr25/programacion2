package ejemploenum;

public enum Equipo {
	BARCA("FC Barcelona", 1), REAL_MADRID("Real Madrid", 2), SEVILLA("Sevilla FC", 4), VILLAREAL("Villarreal", 7);

	private final String nombreClub;
	private final int puestoLiga;

	private Equipo(String nombreClub, int puestoLiga) {
		this.nombreClub = nombreClub;
		this.puestoLiga = puestoLiga;
	}

	public String getNombreClub() {
		return nombreClub;
	}

	public int getPuestoLiga() {
		return puestoLiga;
	}
}