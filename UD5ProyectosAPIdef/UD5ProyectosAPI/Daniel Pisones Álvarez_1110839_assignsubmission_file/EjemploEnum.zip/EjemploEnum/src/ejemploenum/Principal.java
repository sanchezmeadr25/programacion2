package ejemploenum;


import ejemploordenar.CRUDEquipo;
import utilidades.Leer;

public class Principal {
	public static void main(String[] args) {
		CRUDEquipo crud = new CRUDEquipo();

		int opcion= 0;
		do {
			System.out.println("\nEQUIPO:");
			System.out.println("1. Ver TOP 4 equipos Liga");
			System.out.println("2. Crear futbolista");
			System.out.println("3. Ver futbolistas");
			System.out.println("4. Buscar por equipo");
			System.out.println("0. Salir");
			opcion = Leer.datoInt();

			switch (opcion) {
			case 1:
				crud.mostrarEquipos();
				break;
			case 2:
				crud.crearFutbolista();
				break;
			case 3:
				crud.verFutbolistas();
				break;
			case 4:
				crud.buscarPorEquipo();
				break;
			case 0:
				System.out.println("Cerrando programa...");
				break;
			default:
				System.out.println("Opción inválida");
			}

		} while (opcion != 0);
	}
}
