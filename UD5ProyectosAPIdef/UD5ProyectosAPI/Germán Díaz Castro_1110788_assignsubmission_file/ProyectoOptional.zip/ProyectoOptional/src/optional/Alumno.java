package optional;

public class Alumno {
	
    private String dni;
    private String nombre;
    private Double notaMedia;
    
    
	public Alumno(String dni, String nombre, Double notaMedia) {
		super();
		this.dni = dni;
		this.nombre = nombre;
		this.notaMedia = notaMedia;
	}

	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Double getNotaMedia() {
		return notaMedia;
	}
	public void setNotaMedia(Double notaMedia) {
		this.notaMedia = notaMedia;
	}

	
	@Override
	public String toString() {
		return "Alumno [dni=" + dni + ", nombre=" + nombre + ", notaMedia=" + notaMedia + "]";
	}

    
	
}