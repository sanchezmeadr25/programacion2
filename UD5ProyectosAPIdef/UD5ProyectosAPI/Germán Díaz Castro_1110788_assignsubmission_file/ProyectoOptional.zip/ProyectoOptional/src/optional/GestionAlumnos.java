package optional;

import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Optional;

public class GestionAlumnos {
    
    private ArrayList<Alumno> listaAlumnos = new ArrayList<>();

    
    public GestionAlumnos(ArrayList<Alumno> listaAlumnos) {
		super();
		this.listaAlumnos = listaAlumnos;
	}
    public GestionAlumnos() {
        // Constructor vacío
    }
    

	public ArrayList<Alumno> getListaAlumnos() {
		return listaAlumnos;
	}
	public void setListaAlumnos(ArrayList<Alumno> listaAlumnos) {
		this.listaAlumnos = listaAlumnos;
	}

	@Override
	public String toString() {
		return "GestionAlumnos [listaAlumnos=" + listaAlumnos + "]";
	}



    public void agregarAlumno(Alumno a) {
    	
        listaAlumnos.add(a);
    }

    // --------------------------------Devolvemos la caja en lugar del null, usando .ofNullable y .empty--------------------------------
    public Optional<Alumno> findByDNI(String dni) {	
    	
        
        for (Alumno a : listaAlumnos) {
            if (a.getDni().equals(dni)) {
                
            	return Optional.ofNullable(a);
            }
        }
        return Optional.empty(); 
        
        /* Con .ofNullable() si el bucle encontró algo, lo mete en la caja. 
         * Si el bucle termina sin encontrar coincidencias, devolvemos la caja vacía
         */     
    }

    // -------------------------------- Uso de .ifPresent() --------------------------------
    public void mostrarDatosAlumno(String dni) {
        Optional<Alumno> cajaAlumno = findByDNI(dni);
        
        cajaAlumno.ifPresent(a -> {
            System.out.println(a.toString());
        });
    }

    // -------------------------------- Uso de .orElseThrow() --------------------------------
    public void borrarAlumno(String dni) {
        Optional<Alumno> cajaAlumno = findByDNI(dni);
        
        // Si la caja está vacía, lanza el error y el método se corta aquí.
        // Si tiene algo, saca al alumno y lo guarda.
        Alumno a = cajaAlumno.orElseThrow(() -> 
            new NoSuchElementException("Error: No se puede borrar. El alumno no existe.")
        );
        
        listaAlumnos.remove(a);
    }

    // -------------------------------- Uso de .orElseThrow() --------------------------------
    public void modificarNotaMedia(String dni, double nuevaNota) {
        Optional<Alumno> cajaAlumno = findByDNI(dni);
        
        //Si la caja está vacía, nos mostrará un error. Si tiene algo, simplemente pasa de largo.
        Alumno alumno = cajaAlumno.orElseThrow(() -> 
            new NoSuchElementException("Error: No se puede modificar. El alumno no existe.")
        );
        
        alumno.setNotaMedia(nuevaNota);
    }

    // -------------------------------- Uso de .ofNullable(), .map() y .orElse() --------------------------------
    public String obtenerNombre(Alumno alumno) {
    	
    	String name = "NoName";
        
        // Metemos el alumno en la caja y si es null, la caja estará vacía
        Optional<Alumno> cajaAlumno = Optional.ofNullable(alumno);
        
        // El .map() mira en la caja y si tiene al alumno, coge su nombre y lo mete en otra caja.
        //Si no hay nada devuelve la caja vacía.
        Optional<String> cajaNombre = cajaAlumno.map(a -> a.getNombre());
        
        // Sacamos el texto de esa nueva caja. Si está vacía, usamos el Plan B con .orElse(), que nos devuelve "name"
        String nombre = cajaNombre.orElse(name);
        
        return nombre;
    }
    
}