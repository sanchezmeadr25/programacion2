package optional;

public class Principal {

    public static void main(String[] args) {
        
        System.out.println("GESTIÓN DE ALUMNOS CON OPTIONAL\n\n");
        
        String nombre;
        
        GestionAlumnos ga = new GestionAlumnos();

        Alumno a1 = new Alumno("111A", "Ángel Naranjo", 10.1);
        Alumno a2 = new Alumno("222B", "Miguel Campos", 4.9);

        
        ga.agregarAlumno(a1);
        ga.agregarAlumno(a2);


        System.out.println("--- MOSTRAR DATOS ---");
        System.out.print("Buscando DNI: 111A (Existe): \n");
        ga.mostrarDatosAlumno("111A");
        
        System.out.print("\nBuscando DNI: 999Z (No existe): \n");
        ga.mostrarDatosAlumno("999Z");
        System.out.println("(No devuelve nada y sigue adelante.)");


        System.out.println("\n--- MODIFICAR NOTA ---");
        System.out.println("Modificando nota de 222B a un 4.45:");
        ga.modificarNotaMedia("222B", 4.45);
        ga.mostrarDatosAlumno("222B");


        System.out.println("\n--- BORRAR ALUMNO ---");
        System.out.println("Borramos a 222B (existe):");
        ga.borrarAlumno("222B");
        System.out.println("Si lo buscamos ahora:");
        ga.mostrarDatosAlumno("222B");
        System.out.println("No ha salido nada.");
        
        
        System.out.println("\n--- OBTENER NOMBRE ---");
        nombre = ga.obtenerNombre(a1);
        System.out.println("Pasando un alumno de la lista (a1): " + nombre);
        
        // Probamos pasándole un null para forzar el Plan B con .orElse
        nombre = ga.obtenerNombre(null);
        System.out.println("Pasando un alumno null: " + nombre);
        
        
        System.out.println("\nSi intentamos modificar o borrar un alumno que no existe, nos saldrá el error que hemos creado.");
        System.out.println("");

        ga.modificarNotaMedia("999Z", 9.0);
        ga.borrarAlumno("999Z");

        
        System.out.println("\n FIN DE LAS PRUEBAS");
    }
}
